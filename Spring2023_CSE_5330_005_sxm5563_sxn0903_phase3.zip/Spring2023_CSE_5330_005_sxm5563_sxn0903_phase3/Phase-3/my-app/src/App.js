/* 
Authors :Shubash Muniyappa 1001915563
         Sai Krishna Prateek Nama 1001880903 */



import React, { useState,useEffect,useRef } from 'react';
import axios from 'axios';
import './App.css';
import { Alert } from 'bootstrap';
const App = () => {
  const [searchValue, setSearchValue] = useState('');
  const [itemName, setItemName] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemVendorPrice, setItemVendorPrice] = useState('');
  const [itemPriceToUpdate, setItemPriceToUpdate] = useState('');
  const [itemIdToUpdate, setItemIdToUpdate] = useState('');
  const [itemNameToUpdate, setItemNameToUpdate] = useState('');
  const [itemIdToDelete, setItemIdToDelete] = useState('');
  const [result, setResult] = useState('');
  const [vnameOptions, setVnameOptions] = useState([]); // State to store Vname options
  const [selectedVid, setSelectedVid] = useState(''); // State to store selected Vid
  const [snameOptions, setSnameOptions] = useState([]); // State to store Vname options
  const [selectedsId, setselectedsId] = useState(''); // State to store selected Vid
 // const [vnameOptions, setVnameOptions] = useState([]); // State to store Vname options
  const [itemStoreQTY, setitemStoreQTY] = useState(''); // State to store selected Vid
  const bottomRef = useRef(null);
  useEffect(() => {
    fetchVnameOptions();
    fetchSnameOptions();
  }, []);

 
  const fetchVnameOptions = () => {
    
    axios.get('http://localhost:8000/vendors.php') 
      .then(response => {
        setVnameOptions(response.data); 
      })
      .catch(error => {
        console.error('Error fetching Vname options:', error);
      });
  };
  const fetchSnameOptions = () => {
    axios.get('http://localhost:8000/Store.php') 
      .then(response => {
        setSnameOptions(response.data); 
      })
      .catch(error => {
        console.error('Error fetching Vname options:', error);
      });
  };
  const handleSearch = () => {
    setResult("");
    if (searchValue == ''){
      alert("Item or name required");
    }else{
    axios.get("http://localhost:8000/search_Item.php?searchInput="+'"'+searchValue+'"')
      .then(response => {
        // Handle response and update state with result
        const t = response.data.Iname;
        const t2 = response.data.Sprice;
        const t3 = response.data.iId;
        setResult("Item Name:"+t+",Item Price:"+t2+",Item ID:"+t3);
        setSearchValue("");
      })
      .catch(error => {
        console.error(error);
      });
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleInsert = () => {
    setResult("");
    if (itemName == '' && itemPrice){
      alert("Item name and Price are required");
    }else{
    axios.post("http://localhost:8000/add_item.php?ItemName="+'"'+itemName+'"'+"&ItemPrice="+itemPrice+"&ItemVendorPrice="+itemVendorPrice+"&ItemVendorID="+selectedVid+"&ItemStoreQTY="+itemStoreQTY+"&ItemStoreID="+selectedsId)
      .then(response => {
        // Handle response and update state with result
        setResult(JSON.stringify(response.data));
        setItemName("");
        setItemPrice("");
        setItemVendorPrice("");
        setSelectedVid("");
        setitemStoreQTY("");
        setselectedsId("");
      })
      .catch(error => {
        console.error(error);
      });
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleUpdate = () => {
    setResult("");
    if (itemIdToUpdate == '' && (itemNameToUpdate == '' || itemPriceToUpdate == '')){
      alert("Item  required");
    }else{
    axios.post("http://localhost:8000/update_item.php?itemId="+itemIdToUpdate+"&ItemName="+itemNameToUpdate+"&ItemPrice="+itemPriceToUpdate)
      .then(response => {
        // Handle response and update state with result
        setResult(JSON.stringify(response.data));
        setItemIdToUpdate("");
        setItemNameToUpdate("");
        setItemPriceToUpdate("");
      })
      .catch(error => {
        console.error(error);
      });
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDelete = () => {
    setResult("");
    if (itemIdToDelete == ''){
      alert("Item or name required");
    }else{
    axios.post('http://localhost:8000/delete_item.php?itemId='+itemIdToDelete)
      .then(response => {
        // Handle response and update state with result
        setResult(JSON.stringify(response.data));
        setItemIdToDelete("");
      })
      .catch(error => {
        console.error(error);
      });
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };
  const handleSelectChange = (event) => {
    const selectedOption = event.target.value;
    setSelectedVid(selectedOption); // Update the selected Vid state with the selected option
  };
  const handleSelectChange2 = (event) => {
    const selectedOption = event.target.value;
    setselectedsId(selectedOption); // Update the selected Vid state with the selected option
  };

  return (
    <div className='container'>
      <h1>Item Management System</h1>
      <h2>Search Item</h2>
      <h3>* Marked are mandatory fields</h3>
      <label>Search by Item Name or ID*: </label>
      <input type="text" value={searchValue} onChange={e => setSearchValue(e.target.value)} />
      <button onClick={handleSearch}>Search</button>

      <h2>Insert Item</h2>
      <label>Item Name*: </label>
      <input type="text" value={itemName} onChange={e => setItemName(e.target.value)} />
      <label>Item Price*: </label>
      <input type="text" value={itemPrice} onChange={e => setItemPrice(e.target.value)} />
      <label htmlFor="vnameSelect">Select Vname:</label>
      <select id="vnameSelect" onChange={handleSelectChange}>
        <option value="">Select Vname</option>
        {vnameOptions.map(option => (
          <option key={option.vId} value={option.vId}>{option.Vname}</option>
        ))}
      </select>
      <label>Vendor Item Price: </label>
      <input type="text" value={itemVendorPrice} onChange={e => setItemVendorPrice(e.target.value)} />
      <label htmlFor="snameSelect">Select Store:</label>
      <select id="snameSelect" onChange={handleSelectChange2}>
        <option value="">Select Store</option>
        {snameOptions.map(option => (
          <option key={option.sId} value={option.sId}>{option.Sname}</option>
        ))}
      </select>
      <label>Store Quantity: </label>
      <input type="text" value={itemStoreQTY} onChange={e => setitemStoreQTY(e.target.value)} />
      <button onClick={handleInsert}>Insert</button>

      <h2>Update Item</h2>
      <label>Item ID to Update*: </label>
      <input type="text" value={itemIdToUpdate} onChange={e => setItemIdToUpdate(e.target.value)} />
      <br />
      <h4>Altest one is entry in the below fields is required</h4>
      <label>New Item Name: </label>
      <input type="text" value={itemNameToUpdate} onChange={e => setItemNameToUpdate(e.target.value)} />
      <label>New Item Price: </label>
      <input type="text" value={itemPriceToUpdate} onChange={e => setItemPriceToUpdate(e.target.value)} />
      
      <button onClick={handleUpdate}>Update</button>

      <h2>Delete Item</h2>
      <label>Item ID to Delete*: </label>
      <input type="text" value={itemIdToDelete} onChange={e => setItemIdToDelete(e.target.value)} />
      <button onClick={handleDelete}>Delete</button>

      <h2>Result</h2>
      <div ref={bottomRef}>{result}</div>
    </div>
  );
};

export default App;
