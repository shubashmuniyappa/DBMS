document.getElementById("searchForm").addEventListener("submit", function(event) {
    event.preventDefault();

    var searchInput = document.getElementById("searchInput").value;
    var resultContainer = document.getElementById("result");
    resultContainer.innerHTML = "";

    // Make AJAX request to PHP script to search for item details
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "search_item.php?searchInput=" + searchInput, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Display item details in result container
                resultContainer.innerHTML = xhr.responseText;
            } else {
                console.error("Error fetching item details");
            }
        }
    };
    xhr.send();
});


document.getElementById("addItemForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get form input values
    let itemName = document.getElementById("itemName").value;
    let itemPrice = document.getElementById("itemPrice").value;

    // Perform add item operation using AJAX
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Display result in the result div
                document.getElementById("result").textContent = xhr.responseText;
            } else {
                // Display error message in the result div
                document.getElementById("result").textContent = "Error occurred. Please try again.";
            }
        }
    };
    xhr.open("POST", "/add_item");
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(JSON.stringify({
        itemName: itemName,
        itemPrice: itemPrice
    }));
});

document.getElementById("updateItemForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get
    let itemId = document.getElementById("itemId").value;
let newItemName = document.getElementById("newItemName").value;
// Perform update item operation using AJAX
let xhr = new XMLHttpRequest();
xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
            // Display result in the result div
            document.getElementById("result").textContent = xhr.responseText;
        } else {
            // Display error message in the result div
            document.getElementById("result").textContent = "Error occurred. Please try again.";
        }
    }
};
xhr.open("POST", "/update_item");
xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
xhr.send(JSON.stringify({
    itemId: itemId,
    newItemName: newItemName
}));
});

document.getElementById("deleteItemForm").addEventListener("submit", function(event) {
event.preventDefault();
// Get form input values
let deleteItemId = document.getElementById("deleteItemId").value;

// Perform delete item operation using AJAX
let xhr = new XMLHttpRequest();
xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
            // Display result in the result div
            document.getElementById("result").textContent = xhr.responseText;
        } else {
            // Display error message in the result div
            document.getElementById("result").textContent = "Error occurred. Please try again.";
        }
    }
};
xhr.open("POST", "/delete_item");
xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
xhr.send(JSON.stringify({
    itemId: deleteItemId
}));
});
